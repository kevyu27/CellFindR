# CellFindR
scRNAseq tools for clustering written thanks on a basis for Seurat.

## Introduction
CellFindR is a wraparound for many of the functions that exist in Seurat. It it centered around an iterative clustering algorithm that hopes to find unique cell populations. In addition, CellFindR includes many functions to make plotting and data organization much easier and more friendly for the average biologist. 


### Version 1.0.0 5/16/2019
published onto github! We have submitted our paper!
 
 
**any inquiries or debugging questions ** can send an email to
 *kyu@ucsf.edu* 
 
 
 
